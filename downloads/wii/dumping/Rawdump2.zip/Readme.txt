Install .NET framework 2.0

Use a LG-8164b or LG-8163b or LG-8162b or LG-8161b dvd drive. It might even work with other hitachi drives with GDR in their name (just try, but don't complain).

Start rawdump.exe

You can discuss this programm on: www.wiinewz.com

This version lets you continue a dump after you have stopped an unfinished job .

Changes 0.21 - 0.3:
- keeping image.wod file locked during dump
- extra status information
- some minor bugfixes

Changes 0.3 - 0.4:
- Using streamed reading (about 5 times faster)
- Better info display
- No need voor dvdinfo in the background

Changes 0.4 - 1.0:
- Faster!!! (dumps a Wii disc in 3 hours)
- complete rewrite of dumping code
- error correction
- integrated unscrambler

Changes 1.0 - 1.1:
- Fixed division by zero bug
- took out the gdr drive detection code, so all drives get detected again
- supported by wiinja modchip

Changes 1.1 - 1.2beta:
- Fixed more bugs
- please report bugs on www.wiinewz.com
- removed flash components

Changes 1.2beta - 1.3:
- Changed code to be compatible with Windows x64 and Windows x32
- Fixed random crashes
- Better errorcorrection code

Changes 1.3 - 1.31:
- Fixed occasional arithmetic error

Changes 1.31 - 2.0:
- Faster!! (dumps in about 2.5 hours)
- Faster unscrambling
- Status information while unscrambling
- Works with USB drives!!