
 .------------------------------------------------------------------.
 |                 - wiiKey recovery disc v1.9b -                   |
 |------------------------------------------------------------------|
 |                                                                  |
 | Recovering from a bad flash                                      |
 | ---------------------------                                      |
 | Please note that this is an emergency procedure which should not |
 | have to be performed. If the flashing was interrupted for any    |
 | reason the chip is left in a state where it cannot operate fully.|
 |                                                                  |
 | Burning the recovery disc image                                  |
 | -------------------------------                                  |
 | As media support in Recovery Mode is limited we recommend you    |
 | use DVD-R only for the recovery disc. Burn it with Toast, Image  |
 | Burner, or cdrecord.                                             |
 |                                                                  |
 | Performing the update                                            |
 | ---------------------                                            |
 |                                                                  |
 | - Switch on Wii and eject any disc in drive                      |
 | - Insert recovery disc and reset Wii                             |
 | - Wait for at least 3 minutes. There will *not* be any sign that |
 | the wiikey is recovering, and the recovery disc will not appear  |
 | in Wii menu.                                                     |
 | - Power off the Wii and switch it back on again. wiiKey should   |
 | now have recovered its firmware, and EEPROM will be restored to  |
 | default settings.                                                |
 |                                                                  |
 |                                                                  |

