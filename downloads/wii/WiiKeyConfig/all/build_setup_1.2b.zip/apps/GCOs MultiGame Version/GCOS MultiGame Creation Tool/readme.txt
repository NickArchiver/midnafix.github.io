whatsnew:
** v3 **
- Audio Streaming games now work.
- Fixed up regions for all modchips (Autodetect works now)
- Fixed up syntax on the .exe

Whatsnew:
** SELFBOOT Multigame Ver v2**
- .exe now creates multiboot and selfboot iso all in one.
- NOTE: These new discs won't work on the old MultiGame ver GCOS DVD.
- NOTE: Games Created with previous tool WILL WORK.

Whatsnew:
** Multigame Ver **
- Fixed menu from going to nowhere if up was pressed
- Added support for full DVD MultiGames [new GCOS Format ;)]
- Added Best support possible for Multigame discs (Cobra ones)
- Made GUI Neater in MultiGame select area

Notes:

Using the app:
You must specify a region for the output file.
Examples are:
make-multiv3.exe output.gcm USA game1.gcm game2.gcm etc
make-multiv3.exe output.gcm JAP game1.gcm game2.gcm etc
make-multiv3.exe output.gcm PAL game1.gcm game2.gcm etc

It will create a self-booting GCOS dvd

After a bit of tinkering, GC MultiGames are now working fine on GCOS :) Use our own little application to create GCOS GC MultiGame DVD's up to 4GB (full DVD size to be exact). That's right, GCOS has it first! You may pre-shrink Isos first using GCM Utility 0.5 (one by one).

Takes about 6min give or take to create a ~4.3Gb Iso image.

Why is Cobra MultiGame DVD support only "partial"?
Since Cobra MultiGame DVD's rely on games being on 32kb aligned, some are not playable as this changed now to 128kb. This means that most likely the first title burned on the disc won't work. However instead of removing all support for them, I have left in partial support. GCOS will scan your disc, find whatever it knows will work on Wii drives and only list that.

Technical Notes:
If you want to develop your own app to make these multigame dvd's, here's a rundown of the disc format we made:
-=The GCOS MultiGame DVD Format=-:
Header requires "RGCOSDVD" or "GGCOSDVD" with any padding up to 0x40. (or just rip our header, we don't care)
Offset table is at 0x40, same as CobraMultigame.
First possible location a game can be is at 0x20000.
All games must be placed on offsets divisible by 0x20000 with no remainder. (Aligned)
Max starting offset implemented is 0xFFFFFFFF.
And to keep the n00bs happy, round up the whole size of the .iso to an even number / 2048.
(Self boot gets tricky! if you want that, you'll have to look at the src)


Credits:
Big thanks goes to D00BieBoi for helping out with this release!
