GameCube Action Replay SD Loader V1.00. Copyright 2005.
by Costis (costis@gbaemu.com and http://www.gcdev.com)

README FIRST!!!

===================
 Short Description
===================

The Action Replay SD Loader (or SDLOAD for short) is an tool which
allows you to boot code on an unmodified GameCube within 10 to 15
seconds from the time you turn it on! It makes use of an Action Replay
code which tricks the GameCube into running my bootloader code and loading
my SD card selection menu. The selection menu supports all these features:

- Loading any DOL file from the SD card in any directory and subdirectory.
- Loading any DOL or binary file with PSOload from your computer through
  the network.
- Reloading or exiting back to the SD selection menu from your programs
  by branching to the small reloader code (just like in PSOload V2.00).
- NO need for a modified GameCube, works on ALL unmodified GameCubes.
- Works on EVERY Action Replay revision -- One code to rule them all!
- Only 29 codes to insert once. They are saved on the Action Replay
  memory card after you have written them in the first time and you
  just have to select "Start Game" every subsequent time to boot into
  the SD loader menu.
- Can be installed WITHOUT a way to run code on the GameCube prior to
  this! All you need is an Action Replay, an SD card adapter for the
  GameCube, and an SD card.
- Boots to the SDLOADER selection menu on the FIRST Action Replay boot.

Please read the sections below even though they are lengthy. This can
be the IDEAL GameCube development solution for you! Once you are done
reading and are ready to try out my loader, follow the installation
process in install.txt.

Also, if you are a developer or hacker, I have included a special section
for you at the end of this readme about source code, etc....

Having problems with the loader or cannot get it to work? Post on the
GCDev.com forums with a clear description of your problem or even e-mail
me at costis@gbaemu.com and I will try to get back to you as soon as
possible with the solution. Also, I'd love to hear feedback for this project,
especially after all of the hard work I have to put into it! Send ALL
comments, suggestions, and even constructive criticism to costis@gbaemu.com
as well or likewise post on the forums.


======================
 Detailed Description
======================

Well... As I promised around a week ago, here it is -- my surprise
GameCube release on New Year's day! Happy New Year everyone!!!!

Around two years ago, I released a program called PSOload which allowed
people to boot their own homebrew code on the GameCube by exploiting
a network feature of the online game Phantasy Star Online. GameCube
development has come a long way since then, and I find it simply amazing
how many people have ardently coped with the annoyance and inefficiencies
of having to boot through PSO every single time, waiting for it to load
through the title screens, going through the main menu, and then finally
waiting for it to connect to my loader server! I myself used this method
of code uploading for quite some time (until I lost my PSO disk ;))

I estimate that it takes more than 2 minutes or so to boot code each time
using the PSO exploit method from the time when the GameCube is turned on!
Sure, now that the viper chip has been released and tmbinc has released
sources for his homebrew BIOS replacement chip, people can go modify their
GC's and run code on them right when they are turned on. But there are many
disadvantages to modifying your GameCube...

	1. You have to open your GameCube console, voiding your warranty.
	2. If something goes wrong in the installation, you may be forever
	   left with a broken GameCube.
	3. You can only boot code on that GameCube itself, not on any other
	   unmodified GameCube's so you can't really show your stuff off
	   to friends on their own GC's.
	4. The installation process is much more complicated and there are
	   countless places where it can go wrong...
	5. This new code loading method I have released allows you to develop
	   for the GameCube just as efficiently as with a modified console!

SO what is this tool I am releasing? I like to call it SDLOAD. It is a completely
different method of uploading code on unmodified GC's. It takes approximately
10 to 15 seconds from the time you have turned on your GC to the time you are
able to boot any DOL file of your choice. How does this work you say? My SD
bootloader makes use of the Action Replay in order to exploit the GameCube
and gain full control over it, allowing the user to select any homebrew file
to load and run. The Action Replay is a product made by Datel, which normally
allows users to "enhance" their gaming experiences by entering cheat codes for
GameCube games. It can be bought for around $30 at any local video game store or
online at places such as GameStop (http://www.gamestop.com.)

This is the part that Parasyte contributed a huge amount to... After many hours
of hard work, Parasyte came up with a method to trick ANY version Action Replay
disk to patch *itself* rather than any other game with a small amount of GC
program code encrypted in special Action Replay codes! After the code has been
entered, you select "Start Game", open and close the cover once, and the Action
Replay happily patches itself with a very small amount of code of my choice!

I had an SD card adapter for the GC laying around, so I came up with the idea of
trying to cram an SD card bootloader inside this small code space... After much
optimization and pure PowerPC assembly code writing, I came up with 29 Action
Replay codes which can be used to load code from an SD card, and this is where
SDLOAD was born!

This is how it works... You need an SD card adapter (which you can either buy
from places like Lik-Sang, make yourself -- see included instructions, or kindly
request for me to make and sell you one), an Action Replay disk (can be bought
in most stores), an SD card reader for the PC, and of course... an SD card!
That's it! Just these items and you can be set to run code on ANY unmodified
GameCube within seconds!!! I know how tedious it is to have to enter AR codes
by hand, especially if you do not own a GC keyboard and have to use the controller,
so I have worked very hard and have managed to fit the whole bootloader init code
in only 29 AR codes. To "install" SDLOAD, you just have to enter the bootloader code
in the AR and prepare the SD card with the SD card reader and my included PC program.
After you have completed these two steps, you are set to run the SDLOADER menu program
by simply turning on your GameCube, pressing A to Start Game, and opening and closing
the DVD disk cover.

===============
 SDLOADER MENU
===============

Once you are greeted with the menu, you have the power of running homebrew GC code
in your hands! The menu will display a directory and file listing of all of the
DOL files on the SD card. You can browse through and even go into multiple subdirectories.
Use the UP and DOWN D-PAD buttons to step through the menu items in those directions.
The scrollbar on the right side indicates your current position. Press the A button
over a folder in order to go inside that folder, and press A over a DOL file in order
to load that file from the card and execute it. The L trigger button takes you to
the very top of the directory (HOME), and the R trigger button takes you to the very
bottom of the current directory (END). Pressing the B button will lead you to the parent
directory (alternatively you can press A over the ".." folder item to be taken back
to the parent folder.) Finally, the Z button will always return you to the root
directory of the card.

You can remove the SD card at ANY time while the menu program is running. Once you
have removed the SD card from the memory card slot, the menu will detect this and
will say "REINSERT SD CARD IN SLOT A" at the top right part of the screen. You may
now make any changes to the SD card you want or even reinsert a different SD card,
and the loader will refresh the dir listing.

There is also a preliminary feature for using programs that do not know how to unlock
official Nintendo memory cards properly (specifically GCS...) I believe this may only
work properly with 59 block cards, but whatever. If you use the X button over a DOL file,
the menu will load it just like if you pressed the A button. However, once it has finished
reading the file from the card, it will say "REMOVE SD CARD" at the top right of the screen.
Once you remove the card from the slot, it will request "INSERT MEMCARD". Insert a
memory card into slot A at this point and SDLOADER will unlock it before executing
the DOL file which it has just loaded!

Finally, the last two features of the current release are especially useful for homebrew
developers... I have added a Network Boot feature. This allows you to configure the
SDLOADER menu to initialize the BBA and accept DOL or binary files from PSOload at ANY
time while the menu is running. While the BBA has been activated, the PSOload detection
code is running in the background, so you are still free to traverse through the menus
and select a DOL to boot from the SD card itself. However, once you run PSOload with
the -r option, the menu will say "NETWORK BOOT..." in the top right and will load and
execute a GC executable from PSOload through the network. This should make quick changes
and test cycles extremely efficient, reducing the need to write every new build to the
SD card and exchange it back and forth between your GC and PC reader. Details for
configuring SDLOADER to set up the BBA and work with network boot are all included
in install.txt which is included in this package.

Continuing with the tradition of the reload feature in PSOload, I have included a
reloader feature in SDLOADER as well! In fact, I have been able to make it function
in the exact same way as the PSOload reload feature to the user, except it is even
better this time. Last time, if you executed the reloader before you had PSOload -r
running on your computer, the GameCube would crash. Now, if you jump to the reloader
code, it will reload the menu program from the SD card and execute it, allowing you
to either boot a new DOL from the SD card itself or load another executable from
the network through PSOload -r! Make sure that the sD card is inserted before
using the reloader feature to exit back to the menu, of course. Once again, exact
details for using the reloader feature (including example code for invoking it)
can be found in install.txt

===================
 SD CARD CONNECTOR
===================

I realize that Lik-Sang is one one of the only places where you can buy an SD card
adapter for the GameCube if you are not located in Japan, and they have it for
pretty expensive... ($30 or so). The SD card adapter is very simple hardware, however.
In fact, it is "straight-through" and a homebrew adapter can be made by hacking up
an old GC memory card and soldering a few wires to an SD card connector. SD card connectors
can be removed from cheap SD card readers or even bought as discrete components from
electronic parts stores or online catalogs such as Digikey (http://www.digikey.com).

To make the connector follow this guide:

In this PDF document (http://www.egr.msu.edu/classes/ece480/goodman/fall/group05/deliverables/appnote_foust.pdf)
on the second page, there is a pinout of a standard SD card. Match these pins to your
SD connector.

DarkFader has a memory card connector pinout in this photo:
http://darkfader.net/ngc/files/memcard.jpg

You must connect the two VSS pins (VSS and VSS2) on the SD card connector together
and to GND on the memory card pad (pin 2 or pin 10). You must connect VCC to 3.3V (pin 8).
You must connect the CLK pin on the SD card to the CLK pad on the memcard (pin 11).
You must connect the CS pin on the SD card to the CS pad on the memcard (pin 9).
You must connect the MOSI pin on the SD card to the MOSI pad on the memcard (pin 5).
Finally, you must connect the MISO pin on the SD card to the MISO pad on the memcard (pin 7.)

It's around 3 A.M. at night right now, so I am too tired to write a proper how-to
guide with photos and diagrams, etc. But I have promised to release this tonight,
so I am keeping my promise. I will release such a detailed guide within the coming
days to facilitate the process.

I really do not want the difficulty of obtaining an SD card adapter to hinder
people from using my loader, so if you definitely cannot buy one from an online
store such as Lik-Sang (http://www.lik-sang.com) and do not feel comfortable
making your own, feel free to send me an e-mail and I can probably arrange to make
a homebrew connector for you, provided that you pay all component and shipping
expenses. I estimate that it'll cost maybe around $10-15 or so per connector.

I have high hopes that my SD bootloader will become THE new development solution for
the GameCube. SD cards are high density, so you can put EVERY homebrew DOL file ever
created on an SD card and have them all to load whenever you want. You can take
your Action Replay disk and SD card to friends' houses and show them all your
neat new GameCube stuff on their own GC's. This does NOT require a PC to boot
code once you have the DOL files on your SD card, so you do not have to drag
laptops along with you, and it works on all GameCubes, so you do not have to
bring along your whole GameCube if you are using a mod-chip for development!

PLEASE do not let the SD card connector discourage you from trying out this
loader. Like I said, I would be happy to make a few connectors and give them
out for as cheap as I can without a deficit. Send me an e-mail at costis@gbaemu.com
if you want to do this, although if buying an official adapter is not a problem
for you, *please* respect my time and go for that instead. It will look far more
professional anyway, and you will have the guarantee of its durability. And after
all, $30 is almost nothing compared to the cost and rarity of BroadBand Adapters
right now. The PSO method right now costs around $60 for PSO (which is very
difficult to find in stores because it has been discontinued) and $40 for the BBA.
This totals to around $100! For SDLOAD, the Action Replay costs only $30, and the
SD card adapter costs $30 as well if you get the official one! That totals to around
$60 for a complete GameCube development environment that is arguably even MORE
efficient than modifyng your GC with a mod-chip. You may also be able to find
old Action Replay disks on E-Bay for much cheaper.  

=================
 FOR DEVELOPERS
=================

I have included the full source code of the sdpatch.exe program (see install.txt
for instructions on how to use it and what it is for.) The main reason for this is
that it is specific to NT operating systems (Windows NT/2000/XP) and I have no knowledge
of the Linux or Mac OS X operating systems myself... Knowing that many people use
these alternative operating systems (from experience with PSOload), I have released
the source code so that anyone can port it to any other operating system. sdpatch.exe
does use a lot of system specific calls, but it should easily be portable to Linux
and Mac OS X by replacing them with the low-level equivalents for those OS's. If anyone
ports sdpatch.exe to any other OS than Windows, please contact me and I will upload
it to GCDev.com for posting.

The menu program that is loaded after you open and close the cover on the Action Replay
(SDLOADER) is just a simple file on the SD card. It's the file that you copied to the
root directory of the card while following the installation text called SDLOADER.BIN.
This file is a simple GameCube executable binary which is loaded and copied to RAM
location 0x81700000 (the high 1MB of RAM on the GC's 24MB of main RAM.) You can easily
replace SDLOADER.BIN with your own creation to have it boot at start-up instead of
the default menu if you choose to do so. Just set your compiler to compile for a
target text base section of 0x81700000 (-Ttext 0x81700000) and then use objcopy to
convert the output ELF file from the linker to a binary:

powerpc-elf-objcopy -O binary sdloader.elf SDLOADER.BIN (for example...)

The only precaution you have to take is that your binary file is 1MB or less in size,
as otherwise it will overflow through the top of the GC's RAM!

=======================
 CREDITS AND GREETINGS
=======================

I would like to thank Parasyte first and foremost for making this loader a
possibility. He figured out the incredible Action Replay patching method
which allowed me to create an SD card bootloader code which works on EVERY
Action Replay and on the first boot. He also provided me with stable
network code for interfacing the BroadBand Adapter and helped me test every
stage of the loader as a whole until I got rid of all the visible bugs.

Other credits and greetings (in no specific order) go out to...

DayDream -- HUGE thanks for drawing the SD logo at the top of SDLOADER!!!!
smilydude -- Thanks for making some FAT16 raw test images for me!
BigRedPmp
Lord_NightMare
tmbinc
dovoto
The_1 -- Thanks for testing out some AR codes on your Action Replay!
SubDrag
Sappharad
joat
kevtris
DuoDreamer
DarkFader
groepaz
DesktopMan -- Thanks for donating the SD card connector in the first place!
Myria
Samson
sgstair
asterick
Zeus
JustBurn
Guyfawkes
woo

And everyone else I have missed!!! 

You can contact me at costis@gbaemu.com or by making a post on the GCDev.com forums:
http://forums.gcdev.com. http://www.gcdev.com is and always WILL be the home site
of this project.

Help me make this project a success! AND HAPPY NEW YEAR EVERYONE!!!!!! 