mfe-distro - A Proof Of Concept mini distro using the "mfe"
3 July 2005, Albert "isobel" Herranz


1. INTRODUCTION

  The Nintendo GameCube is a powerful console. As shown in many games,
  it is able to play songs and videos without problems. This was also
  confirmed by building and running MPlayer on it, using the gc-linux port.

  Until recently, running MPlayer on a GameCube was not a trivial task and
  required a Nintendo BroadBand Adapter accessory and a computer to store the
  operating system files and any media files. This is no longer true.

  With the help of the "mfe-distro" proof of concept it is now possible to
  boot a gc-linux based system that will allow you to play media files on your
  GameCube, directly from your console DVD drive.

  Note: "mfe" stands for mini (MPlayer) front-end, and it is a small
        joypad-driven front-end for MPlayer.


2. REQUIREMENTS

  You need a method to send .dol files to your GameCube. You may use PSOload,
  SDload, Samson's AR loader or a modchip, for example.
  If you need assistance with the software based loaders, look for help on
  the www.gcdev.com forums.

  You will also need a DVD writer and some blank DVD-R or DVD+R media.


3. PREPARATIONS

  First of all, you need to burn an iso9660 dvd disc which contains at least
  the following file on the root directory of the disc,
 
    mfe-fs.bz2

  along with your media files or whatever you want to put on this same disc.

  If you are using Linux, you can burn your media using the growisofs utility
  or a combination of a recent mkisofs and cdrecord.

  For example,
  
      # ls dvd-image/
      film1.avi  film2.avi film3.avi  film3.srt  mfe-fs.bz2
      # growisofs -dvd-compat -Z /dev/dvd -R -J dvd-image/

  Remember that the GameCube DVD drive:
  - fails to read unreliable media, specially from low quality brands
  - can't physically read past the first ~1.4GB of data
  - doesn't handle multi-session media
  - may refuse to load partially filled media

  So the recommendations are:
  - always use reliable media
  - do not write more than ~1.4GB (1459978240 bytes) of data to media
  - always perform single-session recordings and "close" the media
  - fill the media with (junk) data up to ~1.4GB


4. RUNNING

  Here follows how to launch the "mfe-distro" proof of concept:

  - Start the mfe-boot.dol on your cube, using one of the loading methods.
    A gc-linux based kernel will show up.

  - If you have not yet put an iso9660 disc containing the mfe-fs.bz2 file
    in your GameCube DVD drive, it will ask you to do so.

  - Once the requested disc is placed, the MPlayer fronted will show up,
    listing the contents of the currently loaded disc.

  - Use the joypad arrows to navigate. Use the B button to go back one
    directory level. Use the A button to play a file or enter a directory.
    Use the L or R buttons to mount/unmount different media.
    (Look at the "mfe" readme for all available joypad bindings).


  And here follows an example on how to actually do it with a working SDload:

  - Copy mfe-boot.dol to your SD card.
    (Use your computer to write to your SD card. Just do this once.)

  - Place your AR disc on your GameCube drive.

  - Put your SD card into your SD card adapter, and insert your SD card
    adapter on Slot A and your memory card with the AR codes on Slot B.

  - Turn on your GameCube.

  - Select "Start Game".

  - Open and close the lid.

  - Once the SDload menu appears, open the lid and put the iso9660 disc with
    the mfe-fs.bz2 on the drive.

  - On the SDload menu, select "MFE-BOOT.DOL" and push the A button.

  - A gc-linux kernel will load and after a few seconds the "mfe" will
    show up. Have fun!

  
5. HOW DOES IT WORK ?

  The mfe proof of concept mini distro is composed by a .dol (mfe-boot.dol)
  carrying a special gc-linux kernel and a .bz2 (mfe-fs.bz2) containing a
  small, customized, compressed filesystem image.

  When the mfe-boot.dol is started it tries to locate the mfe-fs.bz2 file
  in the root directory of an iso9660 disc loaded in the GameCube DVD drive.
  If it doesn't find it, it let's you put another disc on the drive and
  it performs the check again. This process repeats until it succeeds, or
  until you switch off your GameCube :).

  Once the mfe-fs.bz2 is found, the filesystem image is dumped to the ARAM and
  a swap file is created on the remaining space. Then, control is transferred
  to the mini distro on the new filesystem.
  (Yes, you read it right, this mini distro runs from ARAM!)


6. ENHANCEMENTS

  This same concept can be enhanced and/or used with other small applications.

  For example, once we have a working MMC/SD layer, there will be no need
  to burn the mfe-fs.bz2 file on DVD media and we will have the possibility
  to load it from a MMC/SD card. Media files could be also stored on
  MMC/SD cards.


7. CREDITS

  Special thanks go to:

  - kirin for his work on the sw accelerated yuv blitters for our sdl port

  - the MPlayer Project people for their player

  - Paul Davey for letting me use his awesome "Gant" artwork

  - Aubin Paul and the other Freevo developers for granting me permission to
    use one of their background images.

  - the busybox guys for their "swiss army knife"

  - tmbinc and cheqmate for sharing their dvd related findings

  - groepaz for his always useful yagcd

  - all gc-linux and gcdev developers, you know who you are

  - all gc-linux fans and testers


8. DISCLAIMER

   IN NO EVENT SHALL THE AUTHOR BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
   SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
   OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE AUTHOR
   HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

   THE AUTHOR SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING,
   BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
   AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
   ON AN "AS IS" BASIS, AND THE AUTHOR HAS NO OBLIGATION TO
   PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.

   GameCube is a trademark or registered trademark of Nintendo Inc. in
   the US and/or other countries.
   No affiliation between the GameCube-Linux Project and Nintendo Inc. exists
   or is implied. 

