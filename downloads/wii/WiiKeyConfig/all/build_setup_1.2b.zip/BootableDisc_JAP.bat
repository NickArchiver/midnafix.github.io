@del bootdisc.jap.iso
@bootdisc\mkisofs.exe -R -J -G bootdisc/gbi.hdr.jap -no-emul-boot -b bootldr.dol -o ./bootdisc.jap.iso bootdisc/root
@bootdisc\filechop bootdisc.jap.iso 4699979776
