cmd /K "prompt [.] && cls && echo %CD%"



