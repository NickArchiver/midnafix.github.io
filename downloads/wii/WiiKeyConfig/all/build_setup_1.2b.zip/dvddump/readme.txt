  wiiKey DVDDump v0.8 
=====================================================


Requirements:
------------------
 - gamecube SD Adapter  (gecko or selfmade)
 - SDCard 

Most cards other than sdhc should work. We tested various cards from 512mb 
to 2gb. There may be some non-sdhc 4gb cards, but we didnt have one to test 
with. Cards smaller than 512mb should work, but are not recommended as they 
will require too much swapping.


Note:
-------------------
Running dumptool.exe requires administrator privilege. Please login as an 
administrator or member of the administrator group.


Setup:
-------------------
Before using your sdcard for the first time, you need to format it using 
our tool. To do this simply run:

dumptool [driveletter] -c 

This will format the card to fat16 and allocate space for the dumpfile.
It will use all but 10Mb of the available space, in case you want to put
some other applictions on there as well.


Dumping:
--------------------------
Depending on the size of your card the dumper will split up the image to 
multiple chunks. Once a single chunk has been dumped, you must download it
to your computer using dumptool.exe. 

There are two methods for downloading the chunks to your pc. Using the 
option -sd will store the data into a single image file called discimage.iso. 
This is the recommended way, because you dont have to join the parts after 
dumping. 

dumptool [driveletter] -sd

will get the current chunk from the card and append it to the image file 
discimage.iso

Alternatively using the option -d will create a single file for each chunk 
ie. 00.rvl 01.rvl etc. You have join the parts manually when using this method. 

DO *NOT* use multiple cards when dumping a single disc, it will result in bad dumps!

A complete image of a gamecube disc should be exactly 1459978240 bytes 
in size. The correct size for a wii disc image is 4699979776 bytes.



Using the batch files:
--------------------------
If commandlines scare you, you can also use the provided batch files 
formatSD.bat and dump.bat.















