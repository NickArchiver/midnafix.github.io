@set /P SDDRIVELETTER=Please enter the driveletter for your SDCard: 
@cls
@dumptool %SDDRIVELETTER% -sd



