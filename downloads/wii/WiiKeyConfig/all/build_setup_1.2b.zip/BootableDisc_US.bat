@del bootdisc.us.iso
@bootdisc\mkisofs.exe -R -J -G bootdisc/gbi.hdr.us -no-emul-boot -b bootldr.dol -o ./bootdisc.us.iso bootdisc/root
@bootdisc\filechop bootdisc.us.iso 4699979776