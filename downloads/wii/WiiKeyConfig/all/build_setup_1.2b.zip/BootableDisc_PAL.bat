@del bootdisc.pal.iso
@bootdisc\mkisofs.exe -R -J -G bootdisc/gbi.hdr.pal -no-emul-boot -b bootldr.dol -o ./bootdisc.pal.iso bootdisc/root
@bootdisc\filechop bootdisc.pal.iso 4699979776


