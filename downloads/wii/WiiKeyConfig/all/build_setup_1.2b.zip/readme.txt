
 wiiKey base - bootable disc v1.2   README
================================================================



Overview:
=========================================
wiiKey base combines various applications into a single bootable 
disc. This release includes:

 - wiikey configuration
 - wiikey dvdDump (dumps discs to sdcard)
 - some of the most popular gamecube homebrew apps:
 
	- SDLoad 1.0 by Costis
	- Snes9x 1.43 GX 0.5 Port by Softdev
	- GCOs MultiGame Version by emu_kidid
	- MFE Distro 1.0 by Isobel

We like to point out that this disc does not update the chips firmware 
in any way. It merely adjusts the configuration stored in EEPROM.


Quickstart:
===========================================
If you want to add own files to the disc, just copy them to the 
corresponding subdirectory in \bootdisc\root\

bootdisc\root\Dols           for gamecube applications (.dol)
bootdisc\root\Snes           for snes roms (.smc or .zip)
bootdisc\root\Media          for video or audio files

To create the image, simply run the BootableDisc_XXX.bat matching 
your console region. 

Burn the image using any application capable of writing DVD disc 
images i.e. ImgBurn/Nero/CloneCD/cdrecord/DeepBurner/etc


Navigation:
============================================
For those without a gamecube controller, both the main menu and the 
disc dumper support navigation via the reset button. Pressing reset 
for a short time will move the cursor, holding the button for one 
second selects the current entry. The included homebrew apps require 
a gc controller naturally.



wiikey configuration:
============================================

Note:
For stealth reasons the current settings can not be read from 
the chip. That's why running the configuration will show the 
initial settings regardless of the saved setup. 


Region override      [ON/OFF]
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 Enabling this option will make the region of wii/gc games appear to
 be the region of your console, allowing you to boot games from other
 regions. Most NTSC wii games will work on US and JAP consoles. Many
 PAL games will run on NTSC consoles. For a more complete list see:
  
 http://wiki.gbatemp.net/index.php/Wii_Region_Patcher_Compatibility_List

Audiofix            [ON/OFF]	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 Enables fix for gamecube games using streaming audio. If you have 
 backups that are already patched with fstfix, you can disable the 
 option here. 

DVDR Discspeed      [3x/6x]	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 Sets the default speed for recordable media. Fast or silent, you decide!


Disc backup:
======================================
For details on using the disc backup tool, see dvddump\readme.txt.


SDLoad / Snes9x / GcOs / MFE
======================================
Check the corresponding readme files in the apps directory.


whats next ?
===========================================
Coming up next will be the first wiikey firmware update. Among some new
features/improvements, it will fix the audiostreaming bug, that causes 
several gamecube games to crash right now. More details will be 
announced soon on the official website.



Special thanks to:
====================
- Costis for SDLoad 1.0
- Softdev for his great port of Snes9x
- Emu_kidid for GcOs on the wii
- Isobel for the wonderful MFE mplayer frontend

on the web:
====================
http://www.wiikey.cn   - official wiiKey homepage	
http://www.wiinewz.com - the official wiikey forum










